﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using OTMS_App.Models;
using Newtonsoft.Json;
using OTMS_App.Controllers;
using System.Data.Entity;

namespace OTMS_App.Controllers
{
    //Controllers for customer module
    public class CustomerController : Controller
    {
        user obj = TaxiController.obj;
        string Baseurl = "http://localhost:56892/api/customer/";
        private List<booking> usersinfo;
        private customer customerinfo;
        TaxiEntities db = new TaxiEntities(); 
        //Customer books taxi
        public ActionResult CustomerBooking()
        {
            try
            {
                return View("CustomerBooking", "~/Views/Shared/CustomerLayout.cshtml");
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        [HttpPost]
        public async Task<ActionResult> CustomerBooking(booking booking1)
        {
            try { 
            if (Session["user_id"] != null)
            {
                if (booking1.start_time < DateTime.Now)
                {
                    ModelState.AddModelError("start_time", "Start Time should be valid one");
                    return View("CustomerBooking", "~/Views/Shared/CustomerLayout.cshtml");
                }
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    booking1.customer_id = obj.user_id;
                    HttpResponseMessage Res = await client.PostAsJsonAsync<booking>("NewBooking", booking1);
                    return View("CustomerBooking", "~/Views/Shared/CustomerLayout.cshtml");
                }
            }
            else
            {
                return View("CustomerBooking", "~/Views/Shared/CustomerLayout.cshtml");
            }
        }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //Customer Profile
        public async Task<ActionResult> MyProfile()
        {
            try { 
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();

                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage Res = await client.GetAsync("CustomerProfile?customer_id=" + obj.user_id.ToString());


                    if (Res.IsSuccessStatusCode)
                    {
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;


                        customerinfo = JsonConvert.DeserializeObject<customer>(UserResponse);
                    }

                    return View("MyProfile", "~/Views/Shared/CustomerLayout.cshtml", customerinfo);
                }
            }
            else
            {
                return View("MyProfile", "~/Views/Shared/CustomerLayout.cshtml");
            }
        }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        [HttpPost]
        //Customer Edit Profile
        public async Task<ActionResult> MyProfile(customer customer1)
        {
            try { 
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    customer1.customer_id = obj.user_id;
                    HttpResponseMessage Res = await client.PostAsJsonAsync<customer>("EditCustomerProfile", customer1);
                    return View("MyProfile", "~/Views/Shared/CustomerLayout.cshtml");
                }
            }
            else
            {
                return View("MyProfile", "~/Views/Shared/CustomerLayout.cshtml");
            }
        }
           catch
            {
                return RedirectToAction("Error");
            }
        }
        //Customer Booking History
        public async Task<ActionResult> BookingHistoryPage()
        {
            try { 
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();

                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    HttpResponseMessage Res = await client.GetAsync("BookingHistory?customer_id=" + obj.user_id.ToString());


                    if (Res.IsSuccessStatusCode)
                    {
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;


                        usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);
                    }

                    return View("BookingHistoryPage", "~/Views/Shared/CustomerLayout.cshtml", usersinfo);
                }
            }
            else
            {
                return View("BookingHistoryPage", "~/Views/Shared/CustomerLayout.cshtml");
            }
        }
            catch
            {
                return RedirectToAction("Error");
            }

        }
        
        //Help
        public ActionResult Help()
        {
            try
            {
                return View("Help", "~/Views/Shared/CustomerLayout.cshtml");
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //Customer Feedback page 
        public async Task<ActionResult> Feedback(booking booking)
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    if (booking.feedback_id == null)
                    {
                        if (booking.feedback == null)
                        {
                            return View();
                        }
                        else
                        {
                            using (var client = new HttpClient())
                            {
                                feedback feedback = new feedback();
                                feedback = booking.feedback;
                                feedback.customer_id = obj.user_id;
                                client.BaseAddress = new Uri(Baseurl);
                                client.DefaultRequestHeaders.Clear();
                                FeedbackPage feedbackPage = new FeedbackPage();
                                feedbackPage.feedback = feedback;
                                feedbackPage.booking = booking;
                                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                HttpResponseMessage Res = await client.PostAsJsonAsync("Feedback", feedbackPage);
                                return View("FeedbackFilled", "~/Views/Shared/CustomerLayout.cshtml");
                            }
                        }
                    }
                    else
                    {
                        return View("FeedbackFilled", "~/Views/Shared/CustomerLayout.cshtml");
                    }
                }
                else
                {
                    return View("CustomerBooking", "~/Views/Shared/CustomerLayout.cshtml");
                }
            }
            catch
            {
                return RedirectToAction("Error");
            }

        }
        public ActionResult FeedbackFilled()
        {
            try { 
            return View("FeedbackFilled", "~/Views/Shared/CustomerLayout.cshtml");
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //sign out
        public ActionResult SignOut()
        {
            try {
                Session.Remove("user_id");
                return View("../Taxi/Login", "~/Views/Shared/_LoginLayout.cshtml");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        public ActionResult FeedbackResult()
        {
            try { 
                return View("FeedbackResult", "~/Views/Shared/CustomerLayout.cshtml");
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        [HttpPost]
        //error page for exceptions
        public ActionResult Error()
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
    }
}