﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS_EL;
using CMS_Exception;
using CMS_BL;

namespace CustomerManagementSystem
{
    class Program
    {
        CustomerValidation BL = new CustomerValidation();
        //Globally creating Instance
        private static void PrintMenu()
        {
            Console.WriteLine("\n################### Customer Managemnt System Menu ###################");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. List All Customers");
            Console.WriteLine("3. Search Customer by ID");
            Console.WriteLine("4. Search Customer by Name");
            Console.WriteLine("5. Update Customer by ID");
            Console.WriteLine("6. Delete Customer by ID");
            Console.WriteLine("7. Exit");
            Console.WriteLine("##########################################################\n");
        }
        //Method to Add Employee Details
        private void Add()
        {
            try
            {
                Customer C = new Customer();
                Console.Write("Enter Customer ID :");
                C.CustomerID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name :");
                C.CustomerName = Console.ReadLine();
                Console.Write("Enter Customer Age:");
                C.Age = int.Parse(Console.ReadLine());
                Console.Write("Enter Customer City :");
                C.City = Console.ReadLine();
                Console.Write("Enter Customer Phone No.:");
                C.Phone = Console.ReadLine();
                Console.Write("Enter Customer Pincode:");
                C.Pincode = Console.ReadLine();
                bool CustAdded = BL.Add(C);
                if (CustAdded)
                    Console.WriteLine("Customer Added");
                else
                    Console.WriteLine("Customer not Added");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Method to List All Details
        private void ListAll()
        {
            try
            {
                List<Customer> custList = BL.GetAll();
                if (custList != null)
                {
                    Console.WriteLine("#####################################################################");
                    Console.WriteLine("CustomerID\tCustomer Name\tAge\tCity\tPhone No.\tPincode");
                    Console.WriteLine("#####################################################################");
                    foreach (Customer cust in custList)
                    {
                        Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t{4}\t{5}", cust.CustomerID, cust.CustomerName, cust.Age, cust.City, cust.Phone, cust.Pincode);
                    }
                    Console.WriteLine("######################################################################");

                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Method to Search by ID 
        private void SearchByID()
        {
            try
            {
                int id;
                Console.WriteLine("Enter CustomerID to Search:");
                id = Convert.ToInt32(Console.ReadLine());
                Customer search = BL.SearchById(id);
                if (search != null)
                {
                    Console.WriteLine("####################################################################################");
                    Console.WriteLine("CutsomerID\tCustomer Name\tAge\tCity\tPhone No.\tPincode");
                    Console.WriteLine("####################################################################################");
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", search.CustomerID, search.CustomerName, search.Age, search.City, search.Phone, search.Pincode);
                    Console.WriteLine("####################################################################################");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Method to Search by Name
        private void SearchByName()
        {
            try
            {
                string name;
                Console.Write("Enter Customer Name to Search:");
                name = Console.ReadLine();
                Customer search = BL.SearchByName(name);
                if (search != null)
                {
                    Console.WriteLine("####################################################################################");
                    Console.WriteLine("CutsomerID\tCustomer Name\tAge\tCity\tPhone No.\tPincode");
                    Console.WriteLine("####################################################################################");
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", search.CustomerID, search.CustomerName, search.Age, search.City, search.Phone, search.Pincode);
                    Console.WriteLine("####################################################################################");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Method to Update
        private void Update()
        {
            try
            {
                int id;
                Console.Write("Enter Customer ID to Update Details:");
                id = Convert.ToInt32(Console.ReadLine());
                Customer updatedCust = BL.SearchById(id);
                if (updatedCust != null)
                {
                    //Adding one more user input field
                    Console.WriteLine("Enter Which Field to be updated");
                    Console.WriteLine("1.Name\t2.Age\t3.City\t4.Phone No.\t5.Pincode");
                    int c = int.Parse(Console.ReadLine());
                    switch (c)
                    {
                        case 1:
                            Console.WriteLine("Update Customer Name :");
                            updatedCust.CustomerName = Console.ReadLine();
                            break;
                        case 2:
                            Console.WriteLine("Update Age :");
                            updatedCust.Age = int.Parse(Console.ReadLine());
                            break;
                        case 3:
                            Console.WriteLine("Update City :");
                            updatedCust.City = Console.ReadLine();
                            break;
                        case 4:
                            Console.WriteLine("Update Phone No. :");
                            updatedCust.Phone = Console.ReadLine();
                            break;
                        case 5:
                            Console.WriteLine("Update Pincode :");
                            updatedCust.Pincode = Console.ReadLine();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                    bool CustUpdated = BL.Update(updatedCust);
                    if (CustUpdated)
                        Console.WriteLine("Customer Details Updated");
                    else
                        Console.WriteLine("Customer Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        // Method to Delete
        private void Delete()
        {
            try
            {
                int id;
                Console.WriteLine("Enter Customer ID to Delete:");
                id = Convert.ToInt32(Console.ReadLine());
                Customer deleteCust = BL.SearchById(id);
                if (deleteCust != null)
                {
                    bool Custdeleted = BL.Delete(id);
                    if (Custdeleted)
                        Console.WriteLine("Customer Deleted");
                    else
                        Console.WriteLine("Customer not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //Main Method
        static void Main(string[] args)
        {
            Program cust = new Program();
            int choice;
            do
            {
                Console.Clear();
                PrintMenu();
                Console.Write("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        cust.Add();
                        Console.ReadKey();
                        break;
                    case 2:
                        cust.ListAll();
                        Console.ReadKey();
                        break;
                    case 3:
                        cust.SearchByID();
                        Console.ReadKey();
                        break;
                    case 4:
                        cust.SearchByName();
                        Console.ReadKey();
                        break;
                    case 5:
                        cust.Update();
                        Console.ReadKey();
                        break;
                    case 6:
                        cust.Delete();
                        Console.ReadKey();
                        break;
                    case 7:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

    }
}
