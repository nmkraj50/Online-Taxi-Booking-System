﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace OTMS_App.Models
{
    public class UserMetaData
    {
        [Required(ErrorMessage = "Required Field")]
        [RegularExpression(@"^[A-Z][A-Za-z\s]+$", ErrorMessage = "Name should start with capital letter and must have alphabets in it")]
        public string user_name { get; set; }
        [Required(ErrorMessage = "Required Field")]
        [StringLength(10,MinimumLength = 4, ErrorMessage = "Your password be between 4-10 characters")]
        public string user_password { get; set; }
    //    [Required(ErrorMessage = "Required Field")]
    //    [Compare("user_password",ErrorMessage ="Password and Confirm Password should match") ]
    //    public string confirm_password { get; set; }
    }
}