﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS_EL;
using CMS_Exception;

namespace CMS_DAL
{
    public class CustomerRegistration
    {

        public static List<Customer> CustomerList = new List<Customer>();
        //Method to Add Customer
        public bool Add(Customer newCustomer)
        {
            bool CustAdded = false;
            try
            {
                CustomerList.Add(newCustomer);
                CustAdded = true;
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustAdded;

        }
        //Method to Get Details of All Customers 
        public List<Customer> GetAll()
        {
            return CustomerList;
        }
        //Method to Search by ID
        public Customer SearchbyID(int searchCustID)
        {
            Customer searchCustomer = null;
            try
            {
                searchCustomer = CustomerList.Find(cust => cust.CustomerID == searchCustID);
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return searchCustomer;
        }
        //Method to Search by Name
        public Customer SearchByName(string searchName)
        {
            Customer searchCustomer = null;
            try
            {
                searchCustomer = CustomerList.Find(cust => cust.CustomerName == searchName);
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return searchCustomer;
        }
        //Method to Update Customer
        public bool Update(Customer update)
        {
            bool CustUpdated = false;
            try
            {
                for (int i = 0; i < CustomerList.Count; i++)
                {
                    if (CustomerList[i].CustomerID == update.CustomerID)
                    {
                        update.CustomerName = CustomerList[i].CustomerName;
                        update.City = CustomerList[i].City;
                        update.Age = CustomerList[i].Age;
                        update.Phone = CustomerList[i].Phone;
                        update.Pincode = CustomerList[i].Pincode;
                        CustUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustUpdated;
        }
        //Method to Delete Customer
        public bool Delete(int id)
        {
            bool CustDeleted = false;
            try
            {
                Customer deleteCustomer = CustomerList.Find(cust => cust.CustomerID == id);

                if (deleteCustomer != null)
                {
                    CustomerList.Remove(deleteCustomer);
                    CustDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new CustomerException(ex.Message);
            }
            return CustDeleted;

        }
    }
}
