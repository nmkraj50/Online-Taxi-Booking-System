﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using OTMS_App.Models;
using System.Data.Entity;
using System.Net;

namespace OTMS_App.Controllers
{
    //controller for taxi module
    public class TaxiController : Controller
    {
       public  static user obj = new user();
        TaxiEntities db = new TaxiEntities();

        string Baseurl = "http://localhost:56892/api/";
        //Home page for Admin
        public async Task<ActionResult> Index()
        {
            try
            {
                if (Session["user_id"] != null)
                {

                    using (var client = new HttpClient())
                    {

                        List<employee> usersinfo = new List<employee>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/getindex");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<employee>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }


                }

                else
                    return RedirectToAction("taxi/Login");
            }
            catch
            {
                return RedirectToAction("Error");
            }
            
        }
        [HttpPost]
        //Home page to approve registered employees
        public async Task<ActionResult> Index(IList<employee> employees)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //customer1.customer_id = obj.user_id;
                    HttpResponseMessage Res = await client.PostAsJsonAsync("taxi/postindex", employees);
                    return View();
                }
            }
            catch
            {
                return RedirectToAction("Error");
            }
           
        }
        //to manage Employee roster
        public async Task<ActionResult> Roster()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<employee_roster> usersinfo = new List<employee_roster>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/roster");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<employee_roster>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //Display employee details
        public async Task<ActionResult> Users()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<employee> usersinfo = new List<employee>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/get");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<employee>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //display feedbacks
        public async Task<ActionResult> Feedbacks()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<feedback> usersinfo = new List<feedback>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/getfeedback");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<feedback>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //
        //public ActionResult ForgetPassword()
        //{
        //    try
        //    {
        //        return View("ForgetPassword");
        //    }
            
        //    catch
        //    {
        //        return RedirectToAction("Error");
        //    }
        //error page for exceptions
        public ActionResult Error()
        {
            try
            {
                return View();
            }
           
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //password changed confirmation
        public ActionResult PasswordChanged()
        {
            try
            {
                return View();
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }
        [HttpPost]
        //public async Task<ActionResult> ForgetPassword(user user1)
        //{
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            user1.user_id = obj.user_id;
        //            client.BaseAddress = new Uri(Baseurl);
        //            client.DefaultRequestHeaders.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //            HttpResponseMessage Res = await client.PostAsJsonAsync<user>("taxi/ResetPassword", user1);
        //            return View("PasswordChanged");
        //        }
        //    }
            
        //    catch
        //    {
        //        return RedirectToAction("Error");
        //    }
        //}
        //Report
        public ActionResult Report()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("taxi/Login");
            }
           
            catch
            {
                return RedirectToAction("Error");
            }
        }

        public ActionResult ReportCopy()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("taxi/Login");
            }

            catch
            {
                return RedirectToAction("Error");
            }
        }
        //Annual Report
        public async Task<ActionResult> AnnualReport()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<booking> usersinfo = new List<booking>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/annualreport");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //weekly report
        public async Task<ActionResult> weeklyReport()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<booking> usersinfo = new List<booking>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/weeklyreport");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //daily report
        public async Task<ActionResult> DailyReport()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<booking> usersinfo = new List<booking>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/dailyreport");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //admin's profile
        public async Task<ActionResult> MyProfile()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    using (var client = new HttpClient())
                    {

                        List<user> usersinfo = new List<user>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("taxi/profile");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<user>>(UserResponse);

                        }
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //log out 
        [HttpGet]
        public ActionResult LogOut()
        {
            try
            {
                Session.Remove("user_id");
                return RedirectToAction("Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }

        //public ActionResult loginpage(user login)
        //{
        //    var display = db.users.Where(m => m.user_name == login.user_name && m.user_password == login.user_password).FirstOrDefault();
        //    if (display != null)
        //    {
        //        return RedirectToAction("taxi/Users");
        //    }
        //    else
        //    {
        //        ViewBag.Status = "INCORRECT UserName or Password";
        //    }
        //    return View(login);
        //    catch
        //    {
        //        return RedirectToAction("Error");
        //    }
        //}
        //employee registration page
        public ActionResult EmployeeRegistration()
        {
            try
            {
                return View("EmployeeRegistration", "~/Views/Shared/_LoginLayout.cshtml");
            }
         
            catch
            {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EmployeeRegistration([Bind(Include = "User,Employee")] Registration reg)
        {
            try
            {
                

                    //db.users.Add(us);
                    db.users.Add(reg.User);
                    //emp.employee_id = us.user_id ;
                    //emp.employee_name = us.user_name;

                    reg.Employee.employee_id = reg.User.user_id;
                    reg.Employee.employee_name = reg.User.user_name;

                    db.employees.Add(reg.Employee);
                    db.SaveChanges();
                    return RedirectToAction("Login");
               
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //customer registration page
        public ActionResult CustomerRegistration()
        {
            try
            {
                return View("CustomerRegistration", "~/Views/Shared/_LoginLayout.cshtml");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration([Bind(Include = "User,Customer")] Registration reg)

        {
            try
            {
                db.users.Add(reg.User);
                //emp.employee_id = us.user_id ;
                //emp.employee_name = us.user_name;

                reg.Customer.customer_id = reg.User.user_id;
                reg.Customer.customer_name = reg.User.user_name;

                db.customers.Add(reg.Customer);
                db.SaveChanges();
                return RedirectToAction("Login");
            }
            //db.users.Add(us);
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //registration page
        public ActionResult Registration()
        {
            try
            {
                return View("Registration", "~/Views/Shared/_LoginLayout.cshtml");
            }
         
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //login page
        public ActionResult Login()
        {
            try
            {
                if (Session["user_id"] == null)
                    return View("Login", "~/Views/Shared/_LoginLayout.cshtml");
                else
                    return RedirectToAction("taxi/Index");
            }

            catch
            {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(user objUser)
            {
            try
            {
                obj = db.users.Where(a => a.user_id.Equals(objUser.user_id) && a.user_password.Equals(objUser.user_password)).FirstOrDefault();
                if (obj != null)
                {
                    Session["user_id"] = obj.user_id;
                    //Session["user_name"] = obj.user_name.ToString();

                    if (obj.user_role == 1)
                        return RedirectToAction("../employee/EmpIndex");
                    else if (obj.user_role == 2)
                        return RedirectToAction("../Customer/CustomerBooking");
                    else if (obj.user_role == 0)
                        return RedirectToAction("Index");
                    else
                        return RedirectToAction("Login", "~/Views/Shared/_LoginLayout.cshtml");
                }
                return View(objUser);
            }
                 
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //add new roster for employee
        public ActionResult AddRoster()
        {
            try
            {
                if (Session["user_id"] != null)
                {
                    return View();
                }
                else
                    return RedirectToAction("taxi/Login");
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddRoster(employee_roster roster)
        {
            //employee emp = new employee();
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //roster.employee_id = emp.employee_id;
                    HttpResponseMessage Res = await client.PostAsJsonAsync<employee_roster>("taxi/AddRoster", roster);
                    return RedirectToAction("taxi/Roster");
                }
            }
            
            catch
            {
                return RedirectToAction("Error");
            }
        }
        //change password
        public ActionResult ChangePassword(int? id)
        {
            try
            {
                if (id == null)
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                user us = db.users.Find(id);
                if (us == null)
                    return HttpNotFound();
                return View(us);
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        public ActionResult ChangePassword([Bind(Include ="user_password")] user us)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(us).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("taxi/MyProfile");
                }
                return View(us);
            }
            catch
            {
                return RedirectToAction("Error");
            }
        }

        public ActionResult Approve(int? id)
        {
            employee employee = db.employees.Find(id);
            return View(employee);
        }
        [HttpPost]
        public ActionResult Approve([Bind(Include = "employee_id,employee_name,approve_status,govt_id,ratings,available,phone_no")]employee employee)
        {
            db.Entry(employee).State = EntityState.Modified;
            db.SaveChanges();
            return View("Users");
        }
    }
}



