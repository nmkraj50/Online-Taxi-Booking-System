﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using BookingPage.Models;
using Newtonsoft.Json;
namespace BookingPage.Controllers
{
    public class taxiController : Controller
    {
        // GET: taxi
        string Baseurl = "http://localhost:62834/api/taxi/";
        private List<booking> usersinfo;
        private customer customerinfo;
        taxiEntities1 db = new taxiEntities1();
        public ActionResult Login()
        {
            return View("Login","~/Views/Shared/_LoginLayout.cshtml");
        }
        static user obj = new user();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(user objUser)
        {
            if (ModelState.IsValid)
            {
                 obj = db.users.Where(a => a.user_id.Equals(objUser.user_id) && a.user_password.Equals(objUser.user_password)).FirstOrDefault();
                if (obj != null)
                {
                    Session["user_id"] = obj.user_id;
                    //Session["user_name"] = obj.user_name.ToString();

                    if (obj.user_role == 1)
                        return RedirectToAction("EmployeeRegistration");
                    else if (obj.user_role == 2)
                        return RedirectToAction("CustomerBooking");
                    else
                        return RedirectToAction("Login");
                }


            }
            return View("Login", "~/Views/Shared/_LoginLayout.cshtml",objUser);
        }
        public ActionResult CustomerBooking()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> CustomerBooking(booking booking1)
        {
            if(booking1.start_time<DateTime.Now)
            {
                ModelState.AddModelError("start_time", "Start Time should be valid one");
                return View();
            }
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                booking1.customer_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<booking>("NewBooking", booking1);  
                return View();
            }
        }
        public async Task<ActionResult> MyProfile()
        {
            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("CustomerProfile?customer_id=" + obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;


                    customerinfo = JsonConvert.DeserializeObject<customer>(UserResponse);
                }

                return View(customerinfo);
            }
        }
        [HttpPost]
        public async Task<ActionResult> MyProfile(customer customer1)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                customer1.customer_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<customer>("EditCustomerProfile", customer1);
                return View();
            }
        }
        public async Task<ActionResult> BookingHistoryPage()
        {
            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("BookingHistory?customer_id=" + obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                   
                    usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);
                }

                return View(usersinfo);
            }

        }
        public ActionResult Help()
        {
            return View();
        }
       
        public async Task<ActionResult> Feedback(booking booking)
        {
            if (booking.feedback_id == null)
            {
                if (booking.feedback == null)
                { return View(); }
                else
                {
                    using (var client = new HttpClient())
                    {
                        feedback feedback = new feedback();
                        feedback = booking.feedback;
                        feedback.customer_id = obj.user_id;
                        client.BaseAddress = new Uri(Baseurl);
                        client.DefaultRequestHeaders.Clear();
                        FeedbackPage feedbackPage = new FeedbackPage();
                        feedbackPage.feedback = feedback;
                        feedbackPage.booking = booking;
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        HttpResponseMessage Res = await client.PostAsJsonAsync("Feedback", feedbackPage);
                        return View("BookingHistoryPage");
                    }
                }
            }
            else
            {
                return View("FeedbackResult");
            }
            
        }
        public ActionResult SignOut()
        {
            obj = null;
            return View("Login", "~/Views/Shared/_LoginLayout.cshtml");
        }
        public ActionResult ForgetPassword()
        {
            return View("ForgetPassword", "~/Views/Shared/_LoginLayout.cshtml");
        }
        public ActionResult FeedbackResult()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> ForgetPassword(user user1)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.PostAsJsonAsync<user>("ResetPassword", user1);
                return View("Login", "~/Views/Shared/_LoginLayout.cshtml");
            }
        }
    }
}
