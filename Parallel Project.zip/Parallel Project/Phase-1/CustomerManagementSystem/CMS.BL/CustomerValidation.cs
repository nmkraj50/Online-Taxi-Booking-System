﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS_EL;
using CMS_Exception;
using CMS_DAL;
using System.Text.RegularExpressions;

namespace CMS_BL
{
    public class CustomerValidation
    {
        CustomerRegistration dal = new CustomerRegistration();
        private static bool ValidateCust(Customer cust)
        {
            //Validation of input provided by the user
            StringBuilder sb = new StringBuilder();
            bool validCust = true;
            if (cust.CustomerID <= 0)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Invalid Customer ID");
            }
            //Regular Expression to check Name
            Regex regex = new Regex("^[a-zA-Z]+$");
            if (!regex.IsMatch(cust.CustomerName) || cust.CustomerName == String.Empty)
            {
                validCust = false;
                throw new CustomerException(cust.CustomerName, 1);
            }

            //Regular Expression to check City Names
            if (!regex.IsMatch(cust.City) || cust.City == String.Empty)
            {
                validCust = false;
                throw new CustomerException(cust.City, 1);
            }
            if (cust.Age < 0)
            {
                validCust = false;
                sb.Append(Environment.NewLine + "Provide valid Age");
            }
            //validation of Pincode
            Regex regexPincode = new Regex("^[0-9]{6}");
            if (!regexPincode.IsMatch(cust.Pincode) || cust.Pincode == String.Empty)
            {
                validCust = false;
                throw new CustomerException(cust.Pincode, 1);
            }
            //validation of Mobile No.
            Regex regexphone = new Regex("^[6-9]{1}[0-9]{9}");
            if (!regexphone.IsMatch(cust.Phone) || cust.Phone == String.Empty)
            {
                validCust = false;
                throw new CustomerException(cust.Phone, 1);
            }
            if (validCust == false)
                throw new CustomerException(sb.ToString());
            return validCust;
        }
        //Add Customer 
        public bool Add(Customer newCust)
        {
            bool CustAdded = false;
            try
            {
                if (ValidateCust(newCust))
                {
                    //DAL dal = new DAL();
                    CustAdded = dal.Add(newCust);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustAdded;
        }
        //list of customers
        public List<Customer> GetAll()
        {
            List<Customer> CustList = null;
            try
            {
                //DAL dal = new DAL();
                CustList = dal.GetAll();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CustList;
        }
        //customer by ID
        public Customer SearchById(int id)
        {
            Customer searchCust = null;
            try
            {
                //DAL dal = new DAL();
                searchCust = dal.SearchbyID(id);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCust;

        }
        //customer by name
        public Customer SearchByName(string name)
        {
            Customer searchCust = null;
            try
            {
                //DAL dal = new DAL();
                searchCust = dal.SearchByName(name);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCust;

        }
        //update customer
        public bool Update(Customer cust)
        {
            bool CustUpdated = false;
            try
            {
                if (ValidateCust(cust))
                {
                    //DAL dal = new DAL();
                    CustUpdated = dal.Update(cust);
                }
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustUpdated;
        }
        //delete customer
        public bool Delete(int id)
        {
            bool CustDeleted = false;
            try
            {
                if (id > 0)
                {
                    //DAL dal = new DAL();
                    CustDeleted = dal.Delete(id);
                }
                else
                {
                    throw new CustomerException("Invalid Customer ID");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CustDeleted;
        }
    }
}


