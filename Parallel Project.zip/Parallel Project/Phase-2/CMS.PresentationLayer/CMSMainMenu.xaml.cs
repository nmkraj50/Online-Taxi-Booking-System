﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for CMSMainMenu.xaml
    /// </summary>
    public partial class CMSMainMenu : Window
    {
        public CMSMainMenu()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void DisableAllButtons()
        {
            btnCreate.IsEnabled = false;
            btnView.IsEnabled = false;
            btnSearch.IsEnabled = false;
            btnModify.IsEnabled = false;
            btnRemove.IsEnabled = false;
            btnExit.IsEnabled = false;
        }

        public void EnableAllButtons()
        {
            btnCreate.IsEnabled = true;
            btnView.IsEnabled = true;
            btnSearch.IsEnabled = true;
            btnModify.IsEnabled = true;
            btnRemove.IsEnabled = true;
            btnExit.IsEnabled = true;
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            CreateCustomer win1 = new CreateCustomer();
            win1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win1.Show();
            DisableAllButtons();
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            ViewCustomers win2 = new ViewCustomers();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            DisableAllButtons();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerMenu win3 = new SearchCustomerMenu();
            win3.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win3.Show();
            DisableAllButtons();
        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomerMenu win4 = new ModifyCustomerMenu();
            win4.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win4.Show();
            DisableAllButtons();
        }

        

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            EnableAllButtons();
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerMenu win5 = new DeleteCustomerMenu();
            win5.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win5.Show();
            DisableAllButtons();
        }
    }
}
