﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace OTMS_App.Models
{
    public class EmployeeRosterMetaData
    {
        [Required(ErrorMessage = "Required Field")]
        public DateTime in_time { get; set; }
        [Required(ErrorMessage = "Required Field")]
        
        public DateTime out_time { get; set; }
    }
}