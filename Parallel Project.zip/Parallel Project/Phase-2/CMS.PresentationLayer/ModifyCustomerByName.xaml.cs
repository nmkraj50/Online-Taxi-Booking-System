﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerByName.xaml
    /// </summary>
    public partial class ModifyCustomerByName : Window
    {
        public ModifyCustomerByName()
        {
            InitializeComponent();
        }

        private void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchCustomerName = txtName.Text;

                List<Customer> searchCustomers = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                if (searchCustomers != null)
                {
                    dgCustomers.ItemsSource = searchCustomers.ToList();

                }
                else
                {
                    MessageBox.Show("No Customer Details Available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            //if (dgCustomers.SelectedItem != null)
            //{
            //    Customer item = (Customer)dgCustomers.SelectedItem;
            //    int updateCustomerID = item.CustomerID;
            //    Customer updateCustomer = CustomerBLL.SearchCustomerByIdBLL(updateCustomerID);
            //    bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updateCustomer);
            //    if (customerUpdated)
            //    {
            //        MessageBox.Show("Customer Updated!");
            //    }
            //    else
            //    {
            //        MessageBox.Show("Customer Not Updated!");
            //    }
            //    dgCustomers.Items.Refresh();
            //}
            //else
            //{
            //    MessageBox.Show("Customer Not Updated!");
            //}
            Customer row = (Customer)dgCustomers.SelectedItem;
            Customer updatedCustomer = new Customer();

            if(row!=null)
            {
                updatedCustomer.CustomerID = row.CustomerID;
                updatedCustomer.CustomerName = row.CustomerName;
                updatedCustomer.City = row.City;
                updatedCustomer.Age = row.Age;
                updatedCustomer.Phone = row.Phone;
                updatedCustomer.Pincode = row.Pincode;
                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updatedCustomer);
                if(customerUpdated)
                {
                    MessageBox.Show("Customer Updated");
                }
                else
                {
                    MessageBox.Show("Customer Not Updated");
                }
            }
            else
            {
                MessageBox.Show("Customer Details not found");
            }
        }
    }
}

