﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    [System.Web.Http.RoutePrefix("api/taxi")]

    public class taxiController : ApiController
    {
        taxiEntities1 taxi = new taxiEntities1();
        public taxiController()
        {
            taxi.Configuration.ProxyCreationEnabled = false;    
        }
         

        [System.Web.Http.Route("CustomerProfile")]
        public customer GetCustomerProfile(int? customer_id)
        {
            //customer_id = 1001;
            customer customer1 = taxi.customers.Where(e => e.customer_id == customer_id).Single();
            return customer1;
        }

        [System.Web.Http.Route("EditCustomerProfile")]
        public void PostCustomerProfile([FromBody()]customer customer)
        {
            try
            {
                taxi.Entry(customer).State = EntityState.Modified;
                taxi.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        [System.Web.Http.Route("NewBooking")]
        public void PostNewBooking([FromBody()]booking newBooking)
        {
            try
            {
                taxi.bookings.Add(newBooking);
                taxi.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        [System.Web.Http.Route("ResetPassword")]
        public void PostResetPassword([FromBody()]user user)
        {
            try
            {
                user user1 = new user();
                user1 =taxi.users.Where(e => e.user_id == user.user_id).Single();
                user1.user_password = user.user_password;
                taxi.Entry(user1).State = EntityState.Modified;
                taxi.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        [System.Web.Http.Route("Feedback")]
        public void PostFeedback([FromBody()]FeedbackPage feedbackPage)
        {
            try
            {
                booking booking = new booking();
                //booking= taxi.bookings.Where(e => e.customer_id == feedback.customer_id).Where(e=>e.booking_id==feedback.bookings.Select(q=>q.booking_id).FirstOrDefault()).Single();
                 booking = feedbackPage.booking;
                feedback feedback = new feedback();
                feedback feedback1 = new feedback();
                feedback =feedbackPage.feedback;
                taxi.feedbacks.Add(feedback);
                booking = taxi.bookings.Where(e => e.booking_id == booking.booking_id).Single();
                feedback fb = taxi.feedbacks.OrderByDescending(o=>o.feedback_id).First();

                //feedback1 = taxi.feedbacks.Where(e=>e.feedback_id== feedbackPage.feedback.feedback_id).Single();
                booking.feedback_id = fb.feedback_id;
                taxi.Entry(booking).State = EntityState.Modified;
                taxi.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        [System.Web.Http.Route("BookingHistory")]
        public  IEnumerable<booking> GetBookingHistory(int customer_id)
        {
           IList<booking> bookingList = taxi.bookings.Where(e => e.customer_id == customer_id).ToList();
           return bookingList;
        }
        [System.Web.Http.Route("DriverProfile")]
        public employee GetDriverProfile(int employee_id)
        {
            employee employee1 = taxi.employees.Where(e => e.employee_id == employee_id).Single();
            return employee1;
        }
    }
}
