﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace OTMS_App.Models
{
    public class CustomerMetaData
    {
        [Required(ErrorMessage = "Required Field")]
        [RegularExpression(@"^[A-Z][A-Za-z\s]+$", ErrorMessage = "Name should start with capital letter and must have alphabets in it")]
        public string customer_name { get; set; }
        [Required(ErrorMessage = "Required Field")]
        [RegularExpression(@"^[6-9]{1}[0-9]{9}", ErrorMessage = "Invalid Phone No.")]
        public long phone_no { get; set; }
        [RegularExpression(@"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z]",ErrorMessage = "Invalid Email ID")]
        public long email_id { get; set; }
    }
}