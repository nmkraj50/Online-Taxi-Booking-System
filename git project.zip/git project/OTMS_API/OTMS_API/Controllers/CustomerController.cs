﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OTMS_API.Models;
using System.Data.Entity;

namespace TaxiApp.Controllers
{
    [System.Web.Http.RoutePrefix("api/customer")]
    public class CustomerController : ApiController
    {
        TaxiEntities taxi = new TaxiEntities();

        public CustomerController()
        {
            taxi.Configuration.ProxyCreationEnabled = false;
        }


        [System.Web.Http.Route("CustomerProfile")]
        public customer GetCustomerProfile(int? customer_id)
        {
            //customer_id = 1001;
            customer customer1 = taxi.customers.Where(e => e.customer_id == customer_id).Single();
            return customer1;
        }

        [System.Web.Http.Route("NewBooking")]
        public void PostNewBooking([FromBody()]booking newBooking)
        {
            try
            {
                taxi.bookings.Add(newBooking);
                taxi.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }

        }


        [System.Web.Http.Route("bookinghistory")]
        public IEnumerable<booking> GetBookingHistory(int customer_id)
        {
            return taxi.bookings.Where(e => e.customer_id == customer_id).ToList();
            
        }



        [System.Web.Http.Route("DriverProfile")]
        public employee GetDriverProfile(int employee_id)
        {
            employee employee1 = taxi.employees.Where(e => e.employee_id == employee_id).Single();
            return employee1;
        }
    }

}