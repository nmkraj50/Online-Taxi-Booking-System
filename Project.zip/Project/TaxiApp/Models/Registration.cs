﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TaxiApp.Models
{
    public class Registration
    {
        public employee Employee { get; set; }
        public customer Customer { get; set; }
        public user User { get; set; }
    }
}