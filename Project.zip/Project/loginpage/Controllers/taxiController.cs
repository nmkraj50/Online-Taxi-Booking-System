﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace loginpage.Controllers
{
    public class taxiController : Controller
    {
        // GET: taxi
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult loginpage()
        {
            return View();
        }
        public ActionResult newregistration()
        {
            return View();
        }
    }
}