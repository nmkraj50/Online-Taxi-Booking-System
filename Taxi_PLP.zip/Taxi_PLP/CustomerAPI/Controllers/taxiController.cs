﻿using CustomerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;

namespace CustomerAPI.Controllers
{
    public class taxiController : ApiController
    {
        taxiEntities taxi = new taxiEntities();
        //[System.Web.Http.HttpPost]
        //public void NewBooking([Bind(Include = "customer_id,source,destination,hours,fare,start_time,end_time,taxi_type")]booking newBooking)
        //{
        //    try
        //    {
        //        taxi.bookings.Add(newBooking);
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}
        //[System.Web.Http.HttpGet]
        //public IHttpActionResult BookingHistory(int customer_id)
        //{
        //    IList<booking> bookingList = taxi.bookings.Where(e => e.customer_id ==customer_id).ToList();
        //    if (bookingList.Count==0)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(bookingList);
        //}
        //[System.Web.Http.HttpGet]
        [System.Web.Http.Route("xyz")]
        public customer GetCustomerProfile(int customer_id)
        {
            //customer_id = 1001;
            customer customer1 = taxi.customers.Where(e => e.customer_id == customer_id).Single();
            return customer1;
        }
        //[System.Web.Http.HttpGet]
        //public IHttpActionResult DriverProfile(int employee_id)
        //{
        //    employee employee1 = taxi.employees.Where(e => e.employee_id == employee_id).Single();
        //    return Ok(employee1);
        //}
    }
}
