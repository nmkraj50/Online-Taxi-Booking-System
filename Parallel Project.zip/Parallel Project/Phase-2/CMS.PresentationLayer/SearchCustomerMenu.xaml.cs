﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS.PresentationLayer
{
    public partial class SearchCustomerMenu : Window
    {
        public SearchCustomerMenu()
        {
            InitializeComponent();
        }

        private void DisableAllButtons()
        {
            btnSearchByID.IsEnabled = false;
            btnSearchByName.IsEnabled = false;

            btnExit.IsEnabled = false;
        }

        public void EnableAllButtons()
        {
            btnSearchByID.IsEnabled = true;
            btnSearchByName.IsEnabled = true;

            btnExit.IsEnabled = true;
        }

        private void BtnSearchByID_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerByID win1 = new SearchCustomerByID();
            win1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win1.Show();
            DisableAllButtons();
        }

        private void BtnSearchByName_Click(object sender, RoutedEventArgs e)
        {
            SearchCustomerByName win2 = new SearchCustomerByName();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            DisableAllButtons();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            EnableAllButtons();
        }
    }
}
