﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OTMS_App.Models
{
    public class feedbackmetadata
    {
        public int feedback_id { get; set; }
        public Nullable<int> customer_id { get; set; }
        [Required]
        public string feedback_message { get; set; }
        [Required]
        [Range(1, 5)]
        public Nullable<int> feedback_rating { get; set; }
    }
}