﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BookingPage.Models
{
    public class bookingMetadata
    {
        public int booking_id { get; set; }
        public Nullable<int> customer_id { get; set; }
        public Nullable<int> employee_id { get; set; }
        [Required]
        [RegularExpression("[a-zA-Z]+",ErrorMessage ="Should be string")]
        public string source { get; set; }
        [Required]
        [RegularExpression("[a-zA-Z]+", ErrorMessage = "Should be string")]
        public string destination { get; set; }
        [Required]
        //[CheckDateRange]
        public Nullable<System.DateTime> start_time { get; set; }
        [Required]
        //[CheckDateRange]
        public Nullable<System.DateTime> end_time { get; set; }
        [Required]
        [Range(0,48)]
        public Nullable<double> hours { get; set; }
        [Required]
        public Nullable<bool> status { get; set; }
        [Required]
        public Nullable<decimal> fare { get; set; }
        public Nullable<int> feedback_id { get; set; }
        public class CheckDateRangeAttribute : ValidationAttribute
        {
            protected override ValidationResult IsValid(object value, ValidationContext validationContext)
            {
                DateTime dt = new DateTime();
                    dt = (DateTime)value;
                if (dt >= DateTime.UtcNow)
                {
                    return ValidationResult.Success;
                }
                return new ValidationResult(ErrorMessage ?? "Date should be >= than todays date");
            }
        }
    }
}