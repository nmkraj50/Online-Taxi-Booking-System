﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BookingPage.Models
{
    [MetadataType(typeof(bookingMetadata))]
    public partial class booking
    {

    }
}