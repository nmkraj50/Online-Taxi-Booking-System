﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using OTMS_App.Models;
using System.Data.Entity;
using System.Net;

namespace TaxiApp.Controllers
{
    public class TaxiController : Controller
    {
        TaxiEntities db = new TaxiEntities();

        string Baseurl = "http://localhost:56892/api/taxi/";

        public async Task<ActionResult> Index(employee e)
        {
            
            if (Session["user_id"] != null)
            {
                if (e.approve_status == false)
                {
                    using (var client = new HttpClient())
                    {

                        List<employee> usersinfo = new List<employee>();
                        //Passing service base url  
                        client.BaseAddress = new Uri(Baseurl);

                        client.DefaultRequestHeaders.Clear();
                        //Define request data format  
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                        HttpResponseMessage Res = await client.GetAsync("getindex");

                        //Checking the response is successful or not which is sent using HttpClient  
                        if (Res.IsSuccessStatusCode)
                        {
                            //Storing the response details recieved from web api   
                            var UserResponse = Res.Content.ReadAsStringAsync().Result;

                            //Deserializing the response recieved from web api and storing into the Employee list  
                            usersinfo = JsonConvert.DeserializeObject<List<employee>>(UserResponse);

                        }
                        var g = false;
                        if (e.approve_status == true)
                            g = true;
                        else
                            g = false;
                        e.approve_status = g;
                        db.SaveChanges();
                        //returning the employee list to view  
                        return View(usersinfo);
                    }
                }
                else
                {

                }
            }
                
            else
                return RedirectToAction("Login");
        }

        public async Task<ActionResult> Roster()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<employee_roster> usersinfo = new List<employee_roster>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("roster");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<employee_roster>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
            
        }

        public async Task<ActionResult> Users()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<employee> usersinfo = new List<employee>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("get");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<employee>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            return RedirectToAction("Login");
        }

        public async Task<ActionResult> Feedbacks()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<feedback> usersinfo = new List<feedback>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("getfeedback");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<feedback>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
        }

        public ActionResult Report()
        {
            if (Session["user_id"] != null)
            {
                return View();
            }
            else
                return RedirectToAction("Login");
        }

        public async Task<ActionResult> AnnualReport()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {
                
                    List<booking> usersinfo = new List<booking>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("annualreport");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
        }

        public async Task<ActionResult> weeklyReport()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<booking> usersinfo = new List<booking>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("weeklyreport");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
        }

        public async Task<ActionResult> DailyReport()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<booking> usersinfo = new List<booking>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("dailyreport");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
        }

        public async Task<ActionResult> MyProfile()
        {
            if (Session["user_id"] != null)
            {
                using (var client = new HttpClient())
                {

                    List<user> usersinfo = new List<user>();
                    //Passing service base url  
                    client.BaseAddress = new Uri(Baseurl);

                    client.DefaultRequestHeaders.Clear();
                    //Define request data format  
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                    HttpResponseMessage Res = await client.GetAsync("profile");

                    //Checking the response is successful or not which is sent using HttpClient  
                    if (Res.IsSuccessStatusCode)
                    {
                        //Storing the response details recieved from web api   
                        var UserResponse = Res.Content.ReadAsStringAsync().Result;

                        //Deserializing the response recieved from web api and storing into the Employee list  
                        usersinfo = JsonConvert.DeserializeObject<List<user>>(UserResponse);

                    }
                    //returning the employee list to view  
                    return View(usersinfo);
                }
            }
            else
                return RedirectToAction("Login");
        }

        [HttpGet]
        public ActionResult LogOut()
        {

            Session.Remove("user_id");
            return RedirectToAction("Login");
        }

        public ActionResult loginpage(user login)
        {
            var display = db.users.Where(m => m.user_name == login.user_name && m.user_password == login.user_password).FirstOrDefault();
            if (display != null)
            {
                return RedirectToAction("Users");
            }
            else
            {
                ViewBag.Status = "INCORRECT UserName or Password";
            }
            return View(login);
        }

        public ActionResult EmployeeRegistration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EmployeeRegistration([Bind(Include = "User,Employee")] Registration reg)
        {
            if (ModelState.IsValid)
            {

                //db.users.Add(us);
                db.users.Add(reg.User);
                //emp.employee_id = us.user_id ;
                //emp.employee_name = us.user_name;

                reg.Employee.employee_id = reg.User.user_id;
                reg.Employee.employee_name = reg.User.user_name;

                db.employees.Add(reg.Employee);
                db.SaveChanges();
                return RedirectToAction("EmployeeRegistration");
            }
            return View();
        }

        public ActionResult CustomerRegistration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration([Bind(Include = "User,Customer")] Registration reg)

        {
            //db.users.Add(us);
            db.users.Add(reg.User);
            //emp.employee_id = us.user_id ;
            //emp.employee_name = us.user_name;

            reg.Customer.customer_id = reg.User.user_id;
            reg.Customer.customer_name = reg.User.user_name;

            db.customers.Add(reg.Customer);
            db.SaveChanges();
            return RedirectToAction("CustomerRegistration");
        }

        public ActionResult Registration()
        {
            return View();

        }

        public ActionResult Login()
        {
            if (Session["user_id"] == null)
                return View();
            else
                return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(user objUser)
            {
            

                var obj = db.users.Where(a => a.user_id.Equals(objUser.user_id) && a.user_password.Equals(objUser.user_password)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["user_id"] = obj.user_id;
                    //Session["user_name"] = obj.user_name.ToString();

                    if (obj.user_role == 1)
                        return RedirectToAction("EmployeeRegistration");
                    else if (obj.user_role == 2)
                        return RedirectToAction("CustomerBooking");
                    else if (obj.user_role == 0)
                        return RedirectToAction("Index");
                    else
                        return RedirectToAction("Login");
                
               

            }
            return View(objUser);
        }

        public ActionResult AddRoster()
        {
            if (Session["user_id"] != null)
            {
                return View();
            }
            else
                return RedirectToAction("Login");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddRoster(employee_roster roster)
        {
            //employee emp = new employee();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //roster.employee_id = emp.employee_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<employee_roster>("AddRoster", roster);
                return RedirectToAction("Roster");
            }
        }

        public ActionResult ChangePassword(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            user us = db.users.Find(id);
            if (us == null)
                return HttpNotFound();
            return View(us);
        }

        [HttpPost]
        public ActionResult ChangePassword([Bind(Include ="user_password")] user us)
        {
            if(ModelState.IsValid)
            {
                db.Entry(us).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("MyProfile");
            }
            return View(us);
        }
    }
}



