﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace OTMS_App.Models
{
    [MetadataType(typeof(EmployeeRosterMetaData))]
    public partial class employee_roster
    {
    }
}