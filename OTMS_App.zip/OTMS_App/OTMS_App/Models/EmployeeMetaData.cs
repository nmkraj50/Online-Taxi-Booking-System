﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace OTMS_App.Models
{
    public class EmployeeMetaData
    {
        [Required(ErrorMessage ="Required Field")]
        [RegularExpression(@"^[A-Z][A-Za-z\s]+$",ErrorMessage = "Name should start with capital letter and must have alphabets in it")]
        public string employee_name { get; set; }
        [Required(ErrorMessage = "Required Field")]
        [RegularExpression(@"^[6-9]{1}[0-9]{9}", ErrorMessage = "Invalid Phone No.")]
        public long phone_no { get; set; }
        [Required(ErrorMessage = "Required Field")]
        public long govt_id { get; set; }
    }
}