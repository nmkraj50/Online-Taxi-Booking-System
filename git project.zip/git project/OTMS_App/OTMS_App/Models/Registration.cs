﻿using OTMS_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OTMS_App.Models
{
    public class Registration
    {
        public employee Employee { get; set; }
        public customer Customer { get; set; }
        public user User { get; set; }
    }
}