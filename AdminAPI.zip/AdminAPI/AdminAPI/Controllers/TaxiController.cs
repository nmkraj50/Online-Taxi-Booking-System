﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AdminAPI.Models;
using System.Data.Entity;

namespace AdminAPI.Controllers
{
    public class TaxiController : ApiController
    {
        Taxi1Entities db = new Taxi1Entities();
        // GET: api/Taxi
        public IEnumerable<employee> Get()
        {
              
              return db.employees.ToList();
            
        }

        // GET: api/Taxi/5
        public employee Get(int id)
        {
                return db.employees.FirstOrDefault(e => e.employee_id == id);
        }
        public void ChangePassword(employee emp, string password)
        {

            var query =
    from ord in db.users
    where ord.user_id == emp.employee_id
    select ord;

            foreach (user ord in query)
            {
                ord.user_password = password;
                // Insert any additional changes to column values.
            }
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }
        // POST: api/Taxi
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Taxi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Taxi/5
        public void Delete(int id)
        {
        }
    }
}
