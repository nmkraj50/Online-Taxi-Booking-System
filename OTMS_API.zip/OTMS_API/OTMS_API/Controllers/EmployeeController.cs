﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OTMS_API.Models;
namespace OTMS_API.Controllers
{
    [RoutePrefix("api/Employee")]
    public class EmployeeController : ApiController
    {

        Training_13Aug19_PuneEntities db = new Training_13Aug19_PuneEntities();
        [Route("GetRosters")]
        public IEnumerable<employee_roster> GetRoster(int? id)
        {

            IList <employee_roster> employees = db.employee_roster.Where(e => e.employee_id == id).ToList();
            return employees;
        }
        [Route("GetLogs")]
        public IEnumerable<booking> GetLog(int id)
        {
            IList<booking> bookings = db.bookings.Where(e => e.employee_id == id).ToList();
            return bookings;
        }
        [Route("GetAllBookings")]
        public IEnumerable<booking> GetAllBooking(int id)
        {
            IList<booking> bookings = db.bookings.Where(e => e.employee_id == id).ToList();
   
            return bookings;
        }
        [Route("GetEmpProfile")]
        public employee GetEmpProfiles(int? id)
        {

            employee emp = db.employees.Where(e => e.employee_id == id).Single();
            return emp;
        }

        [Route("PostEmpProfile")]
        public void PostEmpProfiles([FromBody()]employee employee)
        {
            try
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        //[HttpGet]
        //public employee Availability(bool avail, int id)
        //{

        //    employee emp = db.employees.FirstOrDefault();

        //    emp.available = avail;
        //    try
        //    {
        //        db.Entry(emp).State = EntityState.Modified;
        //        db.SaveChanges();
        //    }
        //    catch(Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }

        //    return db.employees.FirstOrDefault();

        //}



        [HttpGet]
        [Route("Delete")]
        public IHttpActionResult Deletes(int id)
        {
            if (id <= 0)
                return BadRequest("Not a valid student id");

            try
            {
                var log = db.employee_log
                    .Where(e => e.log_id == id)
                    .FirstOrDefault();

                db.Entry(log).State = EntityState.Deleted;
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return Ok();
        }

    }
}
