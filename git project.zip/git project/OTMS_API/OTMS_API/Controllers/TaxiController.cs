﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using OTMS_API.Models;

namespace TaxiApp.Controllers
{
    [RoutePrefix("api/taxi")]
    public class TaxiController : ApiController
    {

       
        public TaxiController()
        {
            // Add the following code
            // problem will be solved
            db.Configuration.ProxyCreationEnabled = false;
        }


        TaxiEntities db = new TaxiEntities();
       
        [Route("get")]
        public IEnumerable<employee> Get()
        {
            return db.employees.Where(e => e.approve_status==true).ToList();

        }

        // GET: api/Taxi/5
        [Route("get/id")]
        public employee Get(int? id)
        {
            return db.employees.FirstOrDefault(e => e.employee_id == id);
        }


        [Route("changepassword")]
        public void ChangePassword(int id, string password)
        {

            var query = from ord in db.users where ord.user_id == id select ord;

            foreach (user ord in query)
            {
                ord.user_password = password;
                // Insert any additional changes to column values.
            }
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }

        [Route("getfeedback")]
        public IEnumerable<feedback> GetFeedback()
        {

            return db.feedbacks.ToList();
        }

        [Route("approvestatus")]
        public void ApproveStatus(int id)
        {
            var query = from ord in db.employees where ord.employee_id == id select ord;

            //foreach (employee ord in query)
            //{
            //    bool toggle =  ord.approve_status ;

            //    // Insert any additional changes to column values.
            //    ord.approve_status = !toggle;
            //}
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }
        
        [Route("AddRoster")]
        public void PostAddRoster([FromBody()]employee_roster AddRoster)
        {
            try
            {
                db.employee_roster.Add(AddRoster);
                db.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [Route("roster")]
        public IEnumerable<employee_roster> GetRoster()
        {

            return db.employee_roster.ToList();
        }

        [Route("annualreport")]
        public IEnumerable<booking> GetAnnualReport(DateTime year)
        {

            int y = year.Year;

            year = Convert.ToDateTime(y);
            return db.bookings.Where(b => b.start_time == year).ToList();
            //return db.bookings.Find(e => e. == id);
        }

        
        [Route("weeklyreport")]
        public IEnumerable<booking> GetweeklyReport(DateTime startdate, DateTime enddate)
        {
            DateTime start = startdate.Date;
            DateTime end = enddate.Date;
        
            return db.bookings.Where(b => b.start_time>=start && b.end_time<=end).ToList();
            
        }


        [Route("dailyreport")]
        public IEnumerable<booking> GetDailyReport()
        {
            DateTime dateTime = DateTime.Now;
            DateTime date = dateTime.Date;

            return db.bookings.Where(b => b.start_time == date).ToList();
            //return db.bookings.Find(e => e. == id);
        }

        [Route("getindex")]
        public IEnumerable<employee> GetIndex()
        {
            return db.employees.Where(e => e.approve_status ==null ).ToList();

        }

        [Route("profile")]
        public IEnumerable<user> GetProfile()
        {
            return db.users.Where(e => e.user_role == 0).ToList();

        }

    }
}
