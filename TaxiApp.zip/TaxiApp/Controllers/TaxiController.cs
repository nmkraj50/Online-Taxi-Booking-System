﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using TaxiApp.Models;

namespace TaxiApp.Controllers
{
    public class TaxiController : ApiController
    {
        public TaxiController()
        {
            // Add the following code
            // problem will be solved
            db.Configuration.ProxyCreationEnabled = false;
        }
        TaxiEntities db = new TaxiEntities();
        // GET: api/Taxi
        public IEnumerable<employee> Get()
        {

            return db.employees.ToList();

        }

        // GET: api/Taxi/5
        public employee Get(int? id)
        {
            return db.employees.FirstOrDefault(e => e.employee_id == id);
        }
        public void ChangePassword(int id, string password)
        {

            var query =
    from ord in db.users
    where ord.user_id == id
    select ord;

            foreach (user ord in query)
            {
                ord.user_password = password;
                // Insert any additional changes to column values.
            }
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }
    }
}
