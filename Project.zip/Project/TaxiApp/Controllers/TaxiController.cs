﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using TaxiApp.Models;

namespace TaxiApp.Controllers
{
    public class TaxiController : Controller
    {
        TaxiEntities db = new TaxiEntities();
        
        string Baseurl = "http://localhost:54663/api/";
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Roster()
        {
            return View();
        }
        public async Task<ActionResult> Users()
        {
            using (var client = new HttpClient())
            {

                List<employee> usersinfo = new List<employee>();
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("Taxi/get");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    usersinfo = JsonConvert.DeserializeObject<List<employee>>(UserResponse);

                }
                //returning the employee list to view  
                return View(usersinfo);
            }
        }
        public async Task<ActionResult> Feedbacks()
        {
            using (var client = new HttpClient())
            {

                List<feedback> usersinfo = new List<feedback>();
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("Taxi/getfeedback");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    usersinfo = JsonConvert.DeserializeObject<List<feedback>>(UserResponse);

                }
                //returning the employee list to view  
                return View(usersinfo);
            }
        }
        public ActionResult Report()
        {
            return View();
        }


        public async Task<ActionResult> AnnualReport()
        {
            using (var client = new HttpClient())
            {

                List<booking> usersinfo = new List<booking>();
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("Taxi/annualreport");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                }
                //returning the employee list to view  
                return View(usersinfo);
            }
        }
        public async Task<ActionResult> weeklyReport()
        {
            using (var client = new HttpClient())
            {

                List<booking> usersinfo = new List<booking>();
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("Taxi/weeklyreport");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                }
                //returning the employee list to view  
                return View(usersinfo);
            }
        }

        public async Task<ActionResult> DailyReport()
        {
            using (var client = new HttpClient())
            {

                List<booking> usersinfo = new List<booking>();
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("Taxi/dailyreport");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    usersinfo = JsonConvert.DeserializeObject<List<booking>>(UserResponse);

                }
                //returning the employee list to view  
                return View(usersinfo);
            }
        }

        public ActionResult MyProfile()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            return View();
        }

        public ActionResult loginpage(user login)

        {

            var display = db.users.Where(m => m.user_name == login.user_name && m.user_password == login.user_password).FirstOrDefault();

            if (display != null)

            {
                return RedirectToAction("Users");
                //ViewBag.Status = "CORRECT UserNAme and Password";

            }

            else

            {

                ViewBag.Status = "INCORRECT UserName or Password";

            }

            return View(login);

        }
        [HttpPost]
        public ActionResult newregistration(Registration login)

        {
            Registration db = new Registration();
            if (ModelState.IsValid)
            {
                
                if(ViewBag == "rbCustomer")
                {
                    if (ModelState.IsValid)
                    {
                        
                       db.Customer.
                        db.SaveChanges();
                    }
                }
                db.SaveChanges();
            }
            return View(obj);

        }
    }
}

    
