﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication.Models
{
    public class FeedbackPage
    {
        public feedback feedback { get; set; }
        public booking booking { get; set; }
    }
}