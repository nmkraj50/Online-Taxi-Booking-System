﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS_EL
{
    //Customer Class
    public class Customer
    {
        //Customer Properties
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string City { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
        public string Pincode { get; set; }
        //Construction to initialize values
        public Customer()
        {
            CustomerID = 0;
            CustomerName = string.Empty;
            City = string.Empty;
            Age = 0;
            Phone = string.Empty;
            Pincode = string.Empty;
        }
    }

}
