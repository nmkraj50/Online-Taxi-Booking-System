﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using OTMS_API.Models;

namespace TaxiApp.Controllers
{
    //api for admin module
    [RoutePrefix("api/taxi")]
    public class TaxiController : ApiController
    {

       //to disable proxy
        public TaxiController()
        {
            
            db.Configuration.ProxyCreationEnabled = false;
        }


        Training_13Aug19_PuneEntities db = new Training_13Aug19_PuneEntities();
       //get all registered employee
        [Route("get")]
        public IEnumerable<employee> Get()
        {
            return db.employees.Where(e => e.approve_status==true).ToList();

        }
        //reset password
        [System.Web.Http.Route("ResetPassword")]
        public void PostResetPassword([FromBody()]user user)
        {
            try
            {
                user user1 = new user();
                user1 = db.users.Where(e => e.user_id == user.user_id).Single();
                user1.user_password = user.user_password;
                db.Entry(user1).State = EntityState.Modified;
                db.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        // GET: api/Taxi/5
        [Route("get/id")]
        public employee Get(int? id)
        {
            return db.employees.FirstOrDefault(e => e.employee_id == id);
        }

        //change password
        [Route("changepassword")]
        public void ChangePassword(int id, string password)
        {

            var query = from ord in db.users where ord.user_id == id select ord;

            foreach (user ord in query)
            {
                ord.user_password = password;
                // Insert any additional changes to column values.
            }
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }
        //get feedbacks
        [Route("getfeedback")]
        public IEnumerable<feedback> GetFeedback()
        {

            return db.feedbacks.ToList();
        }
        //approve status for employees
        [Route("approvestatus")]
        public void ApproveStatus(int id)
        {
            var query = from ord in db.employees where ord.employee_id == id select ord;

            //foreach (employee ord in query)
            //{
            //    bool toggle =  ord.approve_status ;

            //    // Insert any additional changes to column values.
            //    ord.approve_status = !toggle;
            //}
            try
            {
                db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
            }
        }
        //add new roster
        [Route("AddRoster")]
        public void PostAddRoster([FromBody()]employee_roster AddRoster)
        {
            try
            {
                db.employee_roster.Add(AddRoster);
                db.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
        }
        //get all roster
        [Route("roster")]
        public IEnumerable<employee_roster> GetRoster()
        {

            return db.employee_roster.ToList();
        }
        //get annual report
        [Route("annualreport")]
        public IEnumerable<booking> GetAnnualReport(DateTime year)
        {

            int y = year.Year;

            year = Convert.ToDateTime(y);
            return db.bookings.Where(b => b.start_time == year).ToList();
            //return db.bookings.Find(e => e. == id);
        }

        //get weekly report
        [Route("weeklyreport")]
        public IEnumerable<booking> GetweeklyReport(DateTime startdate, DateTime enddate)
        {
            DateTime start = startdate.Date;
            DateTime end = enddate.Date;
        
            return db.bookings.Where(b => b.start_time>=start && b.end_time<=end).ToList();
            
        }

        //get daily report
        [Route("dailyreport")]
        public IEnumerable<booking> GetDailyReport()
        {
            DateTime dateTime = DateTime.Now;
            DateTime date = dateTime.Date;

            return db.bookings.Where(b => b.start_time == date).ToList();
            //return db.bookings.Find(e => e. == id);
        }
        //get index page
        [Route("getindex")]
        public IEnumerable<employee> GetIndex()
        {
            return db.employees.Where(e => e.approve_status ==null ).ToList();

        }
        [Route("postindex")]
        public void PostIndex(List<employee> employees)
        {
            foreach(employee item in employees )
            {
                db.Entry(item).State = EntityState.Modified;
            }
            db.SaveChanges();
        }
        //get admin profile
        [Route("profile")]
        public IEnumerable<user> GetProfile()
        {
            return db.users.Where(e => e.user_role == 0).ToList();

        }

    }
}
