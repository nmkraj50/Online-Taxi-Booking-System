﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OTMS_App.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Data.Entity;

namespace OTMS_App.Controllers
{
    public class EmployeeController : Controller
    {
        //connect with ado entity model
         TaxiEntities db = new TaxiEntities();
        string Baseurl = "http://localhost:56892/api/Employee/";
        user obj = TaxiController.obj;

        private employee empInfo;

        //get all pending booking of the user
        public async Task<ActionResult> EmpIndex()
        {
            List<booking> EmpInfo = new List<booking>();

            using (var client = new HttpClient())
            {
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("GetAllBookings?id="+obj.user_id.ToString());

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    EmpInfo = JsonConvert.DeserializeObject<List<booking>>(EmpResponse);

                }
                //returning the employee list to view  
                return View("EmpIndex", "~/Views/Shared/Employee_Layout.cshtml", EmpInfo);
            }
        }
        //get all logs of the employee
        public async Task<ActionResult> Logs()
        {
            List<booking> EmpInfo = new List<booking>();

            using (var client = new HttpClient())
            {
                //obj.user_id = 1000;
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("GetLogs?id=" + obj.user_id.ToString());

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    EmpInfo = JsonConvert.DeserializeObject<List<booking>>(EmpResponse);

                }
                //returning the employee list to view  
                return View("Logs", "~/Views/Shared/Employee_Layout.cshtml", EmpInfo);
            }
        }


        //get all the rooster details of employee
        public async Task<ActionResult> EmpRoster()
        {
            List<employee_roster> empRoster = new List<employee_roster>();


            using (var client = new HttpClient())
            {
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("GetRosters?id="+obj.user_id.ToString());

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    empRoster = JsonConvert.DeserializeObject<List<employee_roster>>(EmpResponse);

                }
                //returning the employee list to view  
                return View("EmpRoster", "~/Views/Shared/Employee_Layout.cshtml",empRoster);
            }
        }

        //get information of employee from DB
        public async Task<ActionResult> EmpProfile()
        {

            employee emp = new employee();

            using (var client = new HttpClient())
            {
                //Passing service base url  

                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("GetProfile?id="+obj.user_id.ToString());

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    emp = JsonConvert.DeserializeObject<employee>(EmpResponse);

                }
                //returning the employee list to view  
                return View("EmpProfile", "~/Views/Shared/Employee_Layout.cshtml",emp);
            }
        }

        //Edit Employee details and post it in the DB
        public async Task<ActionResult> MyEmpProfile()
        {
            using (var client = new HttpClient())
            {
             
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("GetEmpProfile?id=" + obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;


                    empInfo = JsonConvert.DeserializeObject<employee>(UserResponse);
                }

                return View("MyEmpProfile", "~/Views/Shared/Employee_Layout.cshtml",empInfo);
            }
        }
        [HttpPost]
        public async Task<ActionResult> MyEmpProfile(employee emp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                emp.employee_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<employee>("PostEmpProfile", emp);
                return View("MyEmpProfile", "~/Views/Shared/Employee_Layout.cshtml");
            }
        }

        public async Task<ActionResult> Availability()
        {
            using (var client = new HttpClient())
            {
                obj.user_id = 1001;
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("GetAvailability?id=" + obj.user_id.ToString());


                if (Res.IsSuccessStatusCode)
                {
                    var UserResponse = Res.Content.ReadAsStringAsync().Result;


                    empInfo = JsonConvert.DeserializeObject<employee>(UserResponse);
                }

                return View("Availability", "~/Views/Shared/Employee_Layout.cshtml",empInfo);
            }
        }
        [HttpPost]
        public async Task<ActionResult> Availability(employee emp)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                emp.employee_id = obj.user_id;
                HttpResponseMessage Res = await client.PostAsJsonAsync<employee>("PostAvailability1", emp);
                return View("Availability", "~/Views/Shared/Employee_Layout.cshtml");
            }
        }
    }
}